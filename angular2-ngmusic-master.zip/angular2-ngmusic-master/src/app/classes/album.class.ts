export class Album {
	id: number;
}
